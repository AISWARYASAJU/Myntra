Action()
{

	web_url("canonical.html", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	

	web_custom_request("r3.o.lencr.org", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04ZC\\x95t\\x80\\x04+\\x1E\\x82\\xA3\\x1Co\\x86\\xD5\\xE1\\xA8\\xAA", 
		LAST);

	web_custom_request("r3.o.lencr.org_2", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x038.\\xEF\\xAAG\\x99\\xEE\\xC7\\xD7\\xE9\\xBE\\xB7o\\xBBfr\\xB6", 
		LAST);

	web_custom_request("r3.o.lencr.org_3", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04ZC\\x95t\\x80\\x04+\\x1E\\x82\\xA3\\x1Co\\x86\\xD5\\xE1\\xA8\\xAA", 
		LAST);

	web_custom_request("r3.o.lencr.org_4", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\x0F\\xE5\\x1A\\x0E}\\x8A\\xBD\\x03\\x1F\\x8E\\x80I\\xDE\\x03\\x90\\xEC_", 
		LAST);

/*Correlation comment - Do not change!  Original value='Type' Name ='CorrelationParameter' Type ='RecordReplay'*/
	web_reg_save_param_ex(
		"ParamName=CorrelationParameter",
		"LB=Content-",
		"RB=\r\n",
		"Ordinal=2",
		SEARCH_FILTERS,
		"Scope=Headers",
		LAST);

	

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);


	web_custom_request("ocsp.r2m01.amazontrust.com_2", 
		"URL=http://ocsp.r2m01.amazontrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x0B\\xC7\\xE2D\\xDFq\\xD14\\xC0\\xFD\\xCD\\xE3\\xE7\\x11\\xBA\\x8F", 
		LAST);

	web_websocket_send("ID=0",
		"Buffer={\"message{CorrelationParameter}\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1708734750470\\\"\"},\"use_webpush\":true}",
		"IsBinary=0",
		LAST);

	web_websocket_connect("ID=0", 
		"URI=ws://ocsp.digicert.com/", 
		"Origin=wss://push.services.mozilla.com/", 
		"SecWebSocketExtensions=permessage-deflate", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_custom_request("r3.o.lencr.org_5", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14H\\xDA\\xC9\\xA0\\xFB+\\xD3-O\\xF0\\xDEh\\xD2\\xF5g\\xB75\\xF9\\xB3\\xC4\\x04\\x14\\x14.\\xB3\\x17\\xB7XV\\xCB\\xAEP\t@\\xE6\\x1F\\xAF\\x9D\\x8B\\x14\\xC2\\xC6\\x02\\x12\\x03\\x0F\\xE5\\x1A\\x0E}\\x8A\\xBD\\x03\\x1F\\x8E\\x80I\\xDE\\x03\\x90\\xEC_", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_custom_request("c78376db-636c-49a2-8c6a-f8ba1e48684d", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/events/1/c78376db-636c-49a2-8c6a-f8ba1e48684d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":2,\"start_time\":\"2024-02-24T05:55:23.000+05:30\",\"end_time\":\"2024-02-24T06:07:36.442+05:30\",\"reason\":\"startup\",\"experiments\":{\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\""
		"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\""
		"windows_build_number\":19045,\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\",\"architecture\":\"x86_64\",\"app_build\":\"20240213221259\",\"app_channel\":\"release\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"locale\":\"en-GB\",\"app_display_version\":\"123.0\"},\"metrics\":{\"boolean\":{\"urlbar.pref_suggest_nonsponsored\":false,\"urlbar.pref_suggest_sponsored\":false,\"urlbar.pref_suggest_topsites\""
		":true,\"urlbar.pref_suggest_data_collection\":false},\"quantity\":{\"urlbar.pref_max_results\":10},\"uuid\":{\"legacy.telemetry.client_id\":\"e84f4b7b-8d91-483a-9aa4-2d9b47c1055c\"}},\"events\":[{\"timestamp\":0,\"category\":\"fog.validation\",\"name\":\"validate_early_event\"},{\"timestamp\":833,\"category\":\"webcompatreporting\",\"name\":\"reason_dropdown\",\"extra\":{\"setting\":\"required\"}},{\"timestamp\":1082,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"experiment\""
		":\"add-an-image-to-pdf-with-alt-text-rollout\",\"experiment_type\":\"rollout\",\"branch\":\"control\"}},{\"timestamp\":1194,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"experiment_type\":\"rollout\",\"experiment\":\"backgroundupdate-enable-unelevated-installations-rollout-3-release\",\"branch\":\"enabled\"}},{\"timestamp\":1246,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"experiment\":\"csv-import-release-rollout\",\"branch\":\"enable-csv-import\",\""
		"experiment_type\":\"rollout\"}},{\"timestamp\":1260,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"branch\":\"rollout\",\"experiment\":\"ech-roll-out\",\"experiment_type\":\"rollout\"}},{\"timestamp\":1271,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"experiment_type\":\"rollout\",\"experiment\":\"extensions-migration-in-import-wizard-116-rollout\",\"branch\":\"control\"}},{\"timestamp\":1284,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra"
		"\":{\"branch\":\"treatment-a\",\"experiment\":\"mozillaaccounts-toolbar-button-default-visibility-existing-user\",\"experiment_type\":\"rollout\"}},{\"timestamp\":1317,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"experiment\":\"spocs-endpoint-rollout-release\",\"experiment_type\":\"rollout\",\"branch\":\"control\"}},{\"timestamp\":1325,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"branch\":\"treatment\",\"experiment\":\"upgrade-spotlight-rollout\",\""
		"experiment_type\":\"rollout\"}},{\"timestamp\":1329,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"branch\":\"treatment-a\",\"experiment_type\":\"rollout\",\"experiment\":\"launch-firefox-on-os-restart-treatment-a-rollout\"}},{\"timestamp\":1352,\"category\":\"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"experiment_type\":\"rollout\",\"branch\":\"treatment\",\"experiment\":\"device-migration-q4-spotlights-remaining-population\"}},{\"timestamp\":1363,\"category\":\""
		"nimbus_events\",\"name\":\"enrollment\",\"extra\":{\"experiment\":\"picture-in-picture-first-time-use-callout\",\"experiment_type\":\"nimbus\",\"branch\":\"treatment-a\"}},{\"timestamp\":1446,\"category\":\"nimbus_events\",\"name\":\"unenrollment\",\"extra\":{\"experiment\":\"set-firefox-as-default-pdf-handler-on-windows-for-new-users-rollout\",\"reason\":\"recipe-not-seen\",\"branch\":\"treatment\"}},{\"timestamp\":1448,\"category\":\"nimbus_events\",\"name\":\"unenrollment\",\"extra\":{\"branch"
		"\":\"rollout\",\"experiment\":\"first-run-easy-set-up-fx108-rollout\",\"reason\":\"recipe-not-seen\"}},{\"timestamp\":1448,\"category\":\"nimbus_events\",\"name\":\"validation_failed\",\"extra\":{\"feature\":\"accessibilityCache\",\"reason\":\"invalid-feature\",\"experiment\":\"next-generation-accessibility-engine-powering-screen-readers\"}},{\"timestamp\":1448,\"category\":\"nimbus_events\",\"name\":\"is_ready\"},{\"timestamp\":30146,\"category\":\"nimbus_events\",\"name\":\"validation_failed\","
		"\"extra\":{\"feature\":\"accessibilityCache\",\"experiment\":\"next-generation-accessibility-engine-powering-screen-readers\",\"reason\":\"invalid-feature\"}},{\"timestamp\":30146,\"category\":\"nimbus_events\",\"name\":\"is_ready\"},{\"timestamp\":39894,\"category\":\"addons_manager\",\"name\":\"manage\",\"extra\":{\"addon_id\":\"gmp-gmpopenh264\",\"source\":\"gmp-plugin\",\"addon_type\":\"other\",\"method\":\"uninstall\"}}]}", 
		LAST);

	web_custom_request("ocsp.digicert.com_2", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x06'd\\xBD\\xAC\\x97O,\nP\\xA8l\\xF3\\xF9\\x00\\xA6", 
		LAST);

	web_url("update.xml", 
		"URL=https://aus5.mozilla.org/update/6/Firefox/123.0/20240213221259/WINNT_x86_64-msvc-x64/en-GB/release/Windows_NT%252010.0.0.0.19045.3324%2520(x64)/ISET%3ASSE4_2%2CMEM%3A12287/default/default/update.xml?force=1", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("940a957a-cff0-4e3b-b50a-5b28ece2dcc1", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/use-counters/1/940a957a-cff0-4e3b-b50a-5b28ece2dcc1", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":1,\"start_time\":\"2024-02-23T20:30:56.000+05:30\",\"end_time\":\"2024-02-24T06:07:31.464+05:30\",\"reason\":\"app_shutdown_confirmed\",\"experiments\":{\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\""
		"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\""
		"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"os_version\":\""
		"10.0\",\"app_channel\":\"release\",\"app_display_version\":\"123.0\",\"architecture\":\"x86_64\",\"app_build\":\"20240213221259\",\"locale\":\"en-GB\",\"os\":\"Windows\",\"windows_build_number\":19045,\"first_run_date\":\"2023-02-13+05:30\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\"},\"metrics\":{\"counter\":{\"use.counter.page.mixed_content_not_upgraded_image_failure\":1,\"use.counter.css.doc.css_page_break_after\":1,\""
		"use.counter.css.doc.css_backdrop_filter\":1,\"use.counter.css.doc.css_padding_bottom\":2,\"use.counter.css.doc.css_border_right_color\":1,\"use.counter.css.page.css_z_index\":1,\"use.counter.css.doc.css_left\":2,\"use.counter.css.page.css_background_position_x\":1,\"use.counter.css.page.css_translate\":1,\"use.counter.css.doc.css_pointer_events\":2,\"use.counter.css.page.css_webkit_transition_timing_function\":1,\"use.counter.css.doc.css_text_align\":2,\"use.counter.css.doc.css_background_color\""
		":2,\"use.counter.css.page.css_margin_right\":1,\"use.counter.css.doc.css_border_collapse\":1,\"use.counter.css.page.css_min_width\":1,\"use.counter.css.doc.css_vertical_align\":2,\"use.counter.css.page.css_width\":1,\"use.counter.css.doc.css_font\":1,\"use.counter.css.page.css_scroll_behavior\":1,\"use.counter.css.doc.css_animation\":2,\"use.counter.css.page.css_border_left\":1,\"use.counter.css.page.css_text_shadow\":1,\"use.counter.css.doc.css_flex_grow\":1,\"use.counter.css.page.css_box_shadow"
		"\":1,\"use.counter.css.doc.css_font_variant_numeric\":1,\"use.counter.css.page.css_border_style\":1,\"use.counter.css.doc.widows\":1,\"use.counter.css.doc.css_margin_left\":2,\"use.counter.css.page.css_webkit_border_top_right_radius\":1,\"use.counter.css.page.css_webkit_transition\":1,\"use.counter.css.doc.css_webkit_justify_content\":1,\"use.counter.css.doc.css_webkit_box_direction\":1,\"use.counter.css.doc.css_scroll_behavior\":2,\"use.counter.css.doc.css_animation_iteration_count\":1,\""
		"use.counter.css.doc.css_font_weight\":2,\"use.counter.css.doc.css_webkit_box_flex\":1,\"use.counter.css.doc.css_border_left_color\":2,\"use.counter.css.page.css_position\":1,\"use.counter.css.doc.css_flex\":2,\"use.counter.top_level_content_documents_destroyed\":1,\"use.counter.css.doc.css_background_position\":2,\"use.counter.css.page.css_background_clip\":1,\"use.counter.css.page.css_transition_duration\":1,\"use.counter.css.doc.css_height\":3,\""
		"use.counter.css.page.css_animation_iteration_count\":1,\"use.counter.css.page.css_stroke_dasharray\":1,\"use.counter.css.page.css_margin_block_end\":1,\"use.counter.css.page.css_webkit_justify_content\":1,\"use.counter.css.doc.css_webkit_box_orient\":1,\"use.counter.css.doc.css_webkit_box_ordinal_group\":1,\"use.counter.css.page.css_border_right\":1,\"use.counter.css.page.css_transition_delay\":1,\"use.counter.css.page.css_list_style_position\":1,\"use.counter.css.page.css_pointer_events\":1,\""
		"use.counter.css.page.webkit_column_gap\":1,\"use.counter.doc.window_chrome\":1,\"use.counter.css.doc.css_box_sizing\":2,\"use.counter.css.doc.css_webkit_transform_origin\":2,\"use.counter.css.page.css_webkit_box_sizing\":1,\"use.counter.css.doc.css_hyphens\":1,\"use.counter.css.doc.css_clip\":1,\"use.counter.css.page.css_columns\":1,\"use.counter.css.page.css_webkit_user_select\":1,\"use.counter.css.page.css_left\":1,\"use.counter.doc.document_featurepolicy\":1,\""
		"use.counter.css.doc.css_background_position_y\":1,\"use.counter.css.page.css_text_overflow\":1,\"use.counter.css.page.css_border_left_color\":1,\"use.counter.page.mixed_content_not_upgraded_image_success\":1,\"use.counter.css.page.css_animation_name\":1,\"use.counter.css.page.css_webkit_order\":1,\"use.counter.css.page.css_transition_property\":1,\"use.counter.css.doc.css_align_content\":1,\"use.counter.css.page.css_animation\":1,\"use.counter.css.doc.css_moz_transition\":1,\""
		"use.counter.css.doc.css_stroke_width\":2,\"use.counter.css.page.css_border_top_right_radius\":1,\"use.counter.page.document_featurepolicy\":1,\"use.counter.css.page.css_moz_user_select\":1,\"use.counter.doc.mixed_content_not_upgraded_image_success\":1,\"use.counter.css.doc.css_border_color\":2,\"use.counter.css.page.webkit_tap_highlight_color\":1,\"use.counter.css.doc.css_text_decoration\":2,\"use.counter.css.doc.css_webkit_box_shadow\":2,\"use.counter.css.page.css_word_wrap\":1,\""
		"use.counter.css.doc.css_webkit_flex_shrink\":1,\"use.counter.css.page.css_background_repeat\":1,\"use.counter.css.doc.css_border_bottom\":2,\"use.counter.css.doc.css_user_select\":2,\"use.counter.doc.console_log\":1,\"use.counter.css.doc.css_animation_direction\":1,\"use.counter.css.page.css_webkit_text_size_adjust\":1,\"use.counter.css.page.css_font_variant_numeric\":1,\"use.counter.css.page.css_justify_content\":1,\"use.counter.css.doc.css_filter\":1,\""
		"use.counter.css.doc.css_transition_timing_function\":1,\"use.counter.css.page.css_text_indent\":1,\"use.counter.css.page.css_border_top_color\":1,\"use.counter.css.doc.css_border_top_color\":2,\"use.counter.css.page.css_page_break_after\":1,\"use.counter.css.page.css_margin_top\":1,\"use.counter.css.page.css_animation_fill_mode\":1,\"use.counter.css.page.css_list_style_type\":1,\"use.counter.css.doc.css_transform_origin\":2,\"use.counter.css.doc.css_visibility\":2,\"use.counter.css.page.css_clip\""
		":1,\"use.counter.css.page.css_appearance\":1,\"use.counter.css.page.css_font_size\":1,\"use.counter.css.page.css_visibility\":1,\"use.counter.css.page.css_overflow_y\":1,\"use.counter.css.doc.css_margin_block_start\":1,\"use.counter.css.doc.css_webkit_animation_fill_mode\":1,\"use.counter.css.doc.css_letter_spacing\":2,\"use.counter.css.page.css_filter\":1,\"use.counter.css.page.css_grid_column\":1,\"use.counter.css.page.css_touch_action\":1,\"use.counter.css.page.webkit_font_feature_settings\":1,"
		"\"use.counter.css.doc.css_stroke\":2,\"use.counter.css.doc.webkit_tap_highlight_color\":2,\"use.counter.css.doc.css_flex_direction\":2,\"use.counter.css.page.css_color\":1,\"use.counter.css.doc.css_transition_delay\":2,\"use.counter.css.doc.css_max_height\":2,\"use.counter.css.page.css_webkit_border_radius\":1,\"use.counter.css.page.css_resize\":1,\"use.counter.css.doc.css_position\":2,\"use.counter.css.doc.css_border_top_right_radius\":2,\"use.counter.css.doc.css_fill_rule\":1,\""
		"use.counter.css.page.css_webkit_filter\":1,\"use.counter.css.page.css_webkit_flex_shrink\":1,\"use.counter.css.doc.css_background_position_x\":1,\"use.counter.css.doc.css_content\":2,\"use.counter.css.doc.css_webkit_animation\":2,\"use.counter.page.customelementregistry_define\":1,\"use.counter.css.doc.css_margin_block_end\":1,\"use.counter.css.page.widows\":1,\"use.counter.css.doc.css_border_top\":2,\"use.counter.css.doc.css_break_inside\":1,\"use.counter.css.doc.css_font_style\":2,\""
		"use.counter.css.doc.css_text_shadow\":2,\"use.counter.css.doc.css_border\":2,\"use.counter.css.page.css_transform_origin\":1,\"use.counter.css.doc.css_animation_fill_mode\":1,\"use.counter.css.page.css_stroke_width\":1,\"use.counter.css.page.css_webkit_flex_direction\":1,\"use.counter.css.page.css_webkit_box_orient\":1,\"use.counter.css.page.css_overflow\":1,\"use.counter.css.doc.css_place_items\":1,\"use.counter.css.doc.css_appearance\":2,\"use.counter.css.doc.css_webkit_transition_delay\":1,\""
		"use.counter.css.page.css_table_layout\":1,\"use.counter.css.page.css_border_spacing\":1,\"use.counter.css.page.css_webkit_flex\":1,\"use.counter.doc.window_touchlist\":1,\"use.counter.css.page.css_break_inside\":1,\"use.counter.css.page.css_content\":1,\"use.counter.css.doc.css_webkit_transition_timing_function\":1,\"use.counter.css.doc.css_will_change\":1,\"use.counter.css.page.css_order\":1,\"use.counter.css.doc.css_webkit_flex\":1,\"use.counter.css.page.css_background_attachment\":1,\""
		"use.counter.css.doc.css_webkit_transform_style\":1,\"use.counter.css.page.css_border_right_color\":1,\"use.counter.css.page.css_min_height\":1,\"use.counter.css.doc.css_transform\":2,\"use.counter.css.page.css_border_width\":1,\"use.counter.css.page.css_flex_grow\":1,\"use.counter.css.page.css_webkit_animation\":1,\"use.counter.css.page.css_padding_bottom\":1,\"use.counter.css.doc.css_box_shadow\":2,\"use.counter.css.doc.css_overflow_y\":2,\"use.counter.css.page.css_font_feature_settings\":1,\""
		"use.counter.css.page.css_font_style\":1,\"use.counter.css.page.css_webkit_box_align\":1,\"use.counter.css.doc.css_text_decoration_line\":2,\"use.counter.css.doc.css_right\":2,\"use.counter.css.page.css_webkit_transition_duration\":1,\"use.counter.css.doc.css_opacity\":2,\"use.counter.css.page.css_webkit_animation_name\":1,\"use.counter.css.page.css_webkit_animation_delay\":1,\"use.counter.doc.window_paymentrequest\":1,\"use.counter.css.page.css_webkit_box_direction\":1,\""
		"use.counter.css.doc.css_webkit_appearance\":2,\"use.counter.css.page.css_list_style\":1,\"use.counter.css.page.css_will_change\":1,\"use.counter.css.page.css_mix_blend_mode\":1,\"use.counter.css.doc.css_border_left\":2,\"use.counter.css.page.css_text_rendering\":1,\"use.counter.css.page.css_text_transform\":1,\"use.counter.css.page.css_webkit_animation_iteration_count\":1,\"use.counter.css.doc.css_fill\":2,\"use.counter.css.doc.css_webkit_box_align\":2,\"use.counter.css.page.css_top\":1,\""
		"use.counter.css.page.css_webkit_align_self\":1,\"use.counter.css.page.css_float\":1,\"use.counter.css.doc.css_webkit_box_sizing\":2,\"use.counter.css.page.css_overflow_wrap\":1,\"use.counter.css.doc.css_list_style\":2,\"use.counter.css.doc.css_page_break_inside\":1,\"use.counter.css.doc.css_webkit_user_select\":2,\"use.counter.page.domparser_parsefromstring\":1,\"use.counter.page.window_performancelongtasktiming\":1,\"use.counter.css.page.css_white_space\":1,\"use.counter.css.page.css_user_select"
		"\":1,\"use.counter.page.window_touchlist\":1,\"use.counter.css.page.css_display\":1,\"use.counter.css.page.css_background_image\":1,\"use.counter.css.page.css_webkit_flex_grow\":1,\"use.counter.css.doc.css_border_top_left_radius\":2,\"use.counter.css.doc.css_min_width\":2,\"use.counter.css.page.css_font_family\":1,\"use.counter.css.page.css_align_items\":1,\"use.counter.css.page.css_padding_inline_start\":1,\"use.counter.css.doc.css_touch_action\":1,\"use.counter.css.page.css_gap\":1,\""
		"use.counter.css.doc.css_text_overflow\":2,\"use.counter.css.page.css_webkit_flex_basis\":1,\"use.counter.css.doc.css_min_height\":2,\"use.counter.css.page.css_padding_left\":1,\"use.counter.css.doc.css_overflow\":2,\"use.counter.css.page.css_backdrop_filter\":1,\"use.counter.css.page.css_webkit_transform\":1,\"use.counter.css.page.css_bottom\":1,\"use.counter.css.page.css_border_top_left_radius\":1,\"use.counter.css.doc.css_top\":2,\"use.counter.css.doc.css_moz_box_sizing\":1,\""
		"use.counter.css.page.css_stroke_linecap\":1,\"use.counter.css.doc.css_background_repeat\":2,\"use.counter.css.doc.css_padding_top\":2,\"use.counter.css.doc.css_webkit_transform\":2,\"use.counter.css.doc.css_webkit_animation_duration\":1,\"use.counter.css.doc.css_table_layout\":1,\"use.counter.css.doc.orphans\":1,\"use.counter.css.doc.css_white_space\":2,\"use.counter.css.page.css_fill_rule\":1,\"use.counter.css.page.css_webkit_border_top_left_radius\":1,\"use.counter.css.page.css_webkit_box_flex\""
		":1,\"use.counter.css.page.css_flex_basis\":1,\"use.counter.css.page.css_webkit_appearance\":1,\"use.counter.css.doc.css_webkit_transition_property\":1,\"use.counter.css.doc.css_margin_right\":2,\"use.counter.css.page.css_background_color\":1,\"use.counter.css.page.css_outline\":1,\"use.counter.css.page.css_transition\":1,\"use.counter.css.doc.css_text_indent\":2,\"use.counter.css.page.css_direction\":1,\"use.counter.css.doc.css_font_family\":2,\"use.counter.css.page.css_text_decoration\":1,\""
		"use.counter.css.page.css_object_fit\":1,\"use.counter.css.doc.css_width\":3,\"use.counter.css.page.css_grid_template_columns\":1,\"use.counter.css.page.css_margin_left\":1,\"use.counter.css.doc.css_border_left_width\":1,\"use.counter.css.doc.css_order\":2,\"use.counter.css.doc.css_overflow_x\":2,\"use.counter.css.doc.css_cursor\":2,\"use.counter.css.page.css_webkit_box_pack\":1,\"use.counter.css.page.css_animation_timing_function\":1,\"use.counter.css.page.css_hyphens\":1,\""
		"use.counter.css.doc.css_webkit_align_items\":1,\"use.counter.css.page.css_align_content\":1,\"use.counter.css.page.css_word_break\":1,\"use.counter.css.doc.css_border_spacing\":1,\"use.counter.css.doc.css_webkit_align_self\":1,\"use.counter.css.doc.css_border_width\":2,\"use.counter.css.doc.css_flex_wrap\":2,\"use.counter.css.doc.css_transition_property\":2,\"use.counter.css.page.css_flex_direction\":1,\"use.counter.css.page.css_fill\":1,\"use.counter.css.doc.css_line_height\":2,\""
		"use.counter.css.doc.css_border_bottom_left_radius\":1,\"use.counter.css.page.css_opacity\":1,\"use.counter.css.doc.css_transition\":2,\"use.counter.css.doc.webkit_margin_before\":1,\"use.counter.css.page.css_padding_top\":1,\"use.counter.css.page.css_scrollbar_width\":1,\"use.counter.css.page.css_padding\":1,\"use.counter.css.doc.css_background_clip\":1,\"use.counter.css.page.css_background\":1,\"use.counter.css.doc.css_webkit_order\":1,\"use.counter.css.page.css_background_size\":1,\""
		"use.counter.page.window_paymentrequest\":1,\"use.counter.css.doc.css_margin\":2,\"use.counter.css.page.css_animation_duration\":1,\"use.counter.css.page.css_margin\":1,\"use.counter.css.page.css_stroke_dashoffset\":1,\"use.counter.css.page.css_transform_style\":1,\"use.counter.css.doc.css_webkit_flex_grow\":1,\"use.counter.css.doc.css_webkit_flex_basis\":1,\"use.counter.css.page.css_font_weight\":1,\"use.counter.css.doc.css_align_items\":2,\"use.counter.css.page.webkit_margin_before\":1,\""
		"use.counter.css.doc.css_color\":2,\"use.counter.css.page.css_page_break_inside\":1,\"use.counter.css.page.css_height\":1,\"use.counter.css.page.css_stroke_miterlimit\":1,\"use.counter.css.doc.webkit_column_gap\":1,\"use.counter.css.doc.css_background_size\":2,\"use.counter.css.page.css_moz_transform\":1,\"use.counter.css.doc.css_border_radius\":2,\"use.counter.css.doc.css_bottom\":2,\"use.counter.css.doc.css_text_underline_offset\":1,\"use.counter.css.page.css_border_radius\":1,\""
		"use.counter.css.page.css_box_sizing\":1,\"use.counter.css.page.css_webkit_box_ordinal_group\":1,\"use.counter.css.page.css_backface_visibility\":1,\"use.counter.css.doc.css_column_gap\":2,\"use.counter.css.page.css_object_position\":1,\"use.counter.css.page.css_border_color\":1,\"use.counter.css.page.css_border_bottom_color\":1,\"use.counter.dedicated_workers_destroyed\":2,\"use.counter.css.doc.css_moz_user_select\":2,\"use.counter.css.page.css_letter_spacing\":1,\""
		"use.counter.css.page.css_text_underline_offset\":1,\"use.counter.doc.domparser_parsefromstring\":1,\"use.counter.css.doc.css_max_width\":2,\"use.counter.css.doc.css_font_size\":2,\"use.counter.css.doc.css_border_style\":2,\"use.counter.css.doc.css_webkit_animation_iteration_count\":1,\"use.counter.css.doc.css_stroke_dasharray\":1,\"use.counter.css.page.css_outline_style\":1,\"use.counter.css.doc.css_webkit_flex_wrap\":1,\"use.counter.css.doc.css_stroke_linejoin\":1,\""
		"use.counter.css.page.css_max_width\":1,\"use.counter.css.page.css_webkit_align_items\":1,\"use.counter.css.doc.css_grid_column\":1,\"use.counter.css.doc.css_word_break\":2,\"use.counter.css.page.css_border_bottom_left_radius\":1,\"use.counter.css.page.css_justify_self\":1,\"use.counter.content_documents_destroyed\":10,\"use.counter.css.doc.css_columns\":1,\"use.counter.css.doc.css_animation_timing_function\":1,\"use.counter.css.doc.css_webkit_transition_duration\":1,\""
		"use.counter.css.page.css_webkit_transform_style\":1,\"use.counter.doc.mixed_content_not_upgraded_image_failure\":1,\"use.counter.css.doc.css_padding\":2,\"use.counter.css.doc.css_margin_bottom\":2,\"use.counter.css.doc.css_scrollbar_color\":1,\"use.counter.css.doc.css_stroke_miterlimit\":2,\"use.counter.css.page.css_cursor\":1,\"use.counter.css.page.css_moz_transform_origin\":1,\"use.counter.css.doc.webkit_font_smoothing\":1,\"use.counter.css.page.css_vertical_align\":1,\""
		"use.counter.css.page.css_webkit_animation_timing_function\":1,\"use.counter.css.doc.css_justify_content\":2,\"use.counter.css.page.css_border\":1,\"use.counter.css.doc.css_background_attachment\":1,\"use.counter.css.page.css_webkit_flex_wrap\":1,\"use.counter.css.page.css_place_items\":1,\"use.counter.css.page.css_flex_flow\":1,\"use.counter.css.doc.css_resize\":1,\"use.counter.css.doc.css_webkit_animation_direction\":1,\"use.counter.css.page.css_border_collapse\":1,\""
		"use.counter.css.page.css_caret_color\":1,\"use.counter.css.doc.css_flex_basis\":2,\"use.counter.css.doc.css_justify_self\":1,\"use.counter.css.doc.css_text_rendering\":1,\"use.counter.css.page.css_border_left_width\":1,\"use.counter.css.doc.css_direction\":1,\"use.counter.css.doc.css_scrollbar_width\":2,\"use.counter.css.page.css_text_decoration_line\":1,\"use.counter.css.doc.css_webkit_transition\":2,\"use.counter.css.page.css_transition_timing_function\":1,\""
		"use.counter.css.doc.css_webkit_backface_visibility\":1,\"use.counter.css.page.css_webkit_box_shadow\":1,\"use.counter.css.doc.css_stroke_dashoffset\":1,\"use.counter.css.doc.css_translate\":1,\"use.counter.css.doc.css_webkit_border_top_left_radius\":1,\"use.counter.css.doc.css_background_image\":2,\"use.counter.css.doc.css_backface_visibility\":1,\"use.counter.css.doc.css_webkit_filter\":1,\"use.counter.css.page.css_flex\":1,\"use.counter.css.doc.css_animation_name\":1,\""
		"use.counter.css.page.css_webkit_animation_direction\":1,\"use.counter.css.page.css_webkit_backface_visibility\":1,\"use.counter.css.page.css_border_top\":1,\"use.counter.css.doc.css_float\":2,\"use.counter.css.doc.css_animation_duration\":2,\"use.counter.css.doc.css_gap\":2,\"use.counter.doc.customelementregistry_define\":1,\"use.counter.css.doc.css_webkit_text_size_adjust\":1,\"use.counter.css.doc.css_moz_appearance\":2,\"use.counter.css.page.css_column_gap\":1,\""
		"use.counter.css.doc.webkit_margin_after\":1,\"use.counter.doc.window_performancelongtasktiming\":1,\"use.counter.css.doc.css_webkit_animation_delay\":1,\"use.counter.css.page.orphans\":1,\"use.counter.css.doc.css_text_transform\":2,\"use.counter.css.page.css_margin_block_start\":1,\"use.counter.css.doc.css_moz_transform\":1,\"use.counter.css.page.css_transform\":1,\"use.counter.css.doc.css_moz_transform_origin\":1,\"use.counter.css.doc.css_outline\":2,\""
		"use.counter.css.doc.css_webkit_border_top_right_radius\":1,\"use.counter.css.page.css_font\":1,\"use.counter.css.page.webkit_margin_after\":1,\"use.counter.css.doc.css_padding_right\":2,\"use.counter.css.doc.css_margin_top\":2,\"use.counter.css.page.css_webkit_transition_delay\":1,\"use.counter.css.doc.css_flex_shrink\":1,\"use.counter.css.doc.css_padding_inline_start\":1,\"use.counter.css.doc.css_background\":2,\"use.counter.css.page.css_border_bottom_right_radius\":1,\""
		"use.counter.page.console_log\":1,\"use.counter.css.doc.css_webkit_animation_name\":1,\"use.counter.css.doc.css_border_bottom_right_radius\":1,\"use.counter.css.doc.webkit_font_feature_settings\":1,\"use.counter.css.doc.css_overflow_wrap\":2,\"use.counter.css.page.css_stroke\":1,\"use.counter.css.doc.css_grid_template_columns\":2,\"use.counter.css.page.css_animation_direction\":1,\"use.counter.css.page.css_webkit_animation_duration\":1,\"use.counter.css.doc.css_transform_style\":1,\""
		"use.counter.css.page.css_border_image\":1,\"use.counter.css.doc.css_webkit_border_radius\":1,\"use.counter.css.doc.css_word_wrap\":2,\"use.counter.css.doc.css_padding_left\":2,\"use.counter.css.doc.css_webkit_box_pack\":1,\"use.counter.css.page.css_align_self\":1,\"use.counter.css.doc.css_border_bottom_color\":2,\"use.counter.css.doc.css_transition_duration\":2,\"use.counter.css.page.css_margin_bottom\":1,\"use.counter.css.page.css_right\":1,\"use.counter.css.page.css_webkit_transition_property\""
		":1,\"use.counter.css.doc.css_z_index\":2,\"use.counter.css.doc.webkit_padding_start\":1,\"use.counter.css.page.css_moz_transition\":1,\"use.counter.page.window_chrome\":1,\"use.counter.css.page.css_overflow_x\":1,\"use.counter.css.doc.css_webkit_flex_direction\":1,\"use.counter.css.page.css_animation_delay\":1,\"use.counter.css.doc.css_flex_flow\":1,\"use.counter.css.doc.css_animation_delay\":2,\"use.counter.css.doc.css_display\":2,\"use.counter.css.page.css_stroke_linejoin\":1,\""
		"use.counter.css.page.css_text_align\":1,\"use.counter.css.doc.css_border_right\":2,\"use.counter.css.doc.css_list_style_position\":1,\"use.counter.css.page.css_background_position_y\":1,\"use.counter.css.page.css_line_height\":1,\"use.counter.css.page.css_webkit_transform_origin\":1,\"use.counter.css.page.css_moz_box_sizing\":1,\"use.counter.css.page.css_padding_right\":1,\"use.counter.css.page.css_scrollbar_color\":1,\"use.counter.css.page.webkit_font_smoothing\":1,\""
		"use.counter.css.doc.css_font_feature_settings\":2,\"use.counter.css.doc.css_object_position\":1,\"use.counter.css.doc.css_caret_color\":1,\"use.counter.css.page.css_flex_shrink\":1,\"use.counter.css.doc.css_outline_style\":1,\"use.counter.css.page.webkit_padding_start\":1,\"use.counter.css.page.css_background_position\":1,\"use.counter.css.page.css_max_height\":1,\"use.counter.css.doc.css_stroke_linecap\":1,\"use.counter.css.doc.css_align_self\":2,\"use.counter.css.page.css_clear\":1,\""
		"use.counter.css.doc.css_border_image\":1,\"use.counter.css.doc.css_clear\":2,\"use.counter.css.doc.css_webkit_animation_timing_function\":1,\"use.counter.css.page.css_moz_appearance\":1,\"use.counter.css.page.css_webkit_animation_fill_mode\":1,\"use.counter.css.page.css_flex_wrap\":1,\"use.counter.css.page.css_border_bottom\":1,\"use.counter.css.doc.css_list_style_type\":1,\"use.counter.css.doc.css_mix_blend_mode\":2,\"use.counter.css.doc.css_object_fit\":2}}}", 
		LAST);

	web_custom_request("e23fb64b-82ce-4693-b05f-cdfcc8c3eb1e", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/e23fb64b-82ce-4693-b05f-cdfcc8c3eb1e", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":4,\"start_time\":\"2024-02-24T05:55:23.000+05:30\",\"end_time\":\"2024-02-24T06:07:36.507+05:30\",\"reason\":\"component_init\"},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\",\"os_version\":\"10.0\",\"os\":\"Windows\",\"app_build\":\"20240213221259\",\"app_display_version\":\"123.0\",\"app_channel\":\"release\",\"architecture\":\"x86_64\",\"locale\":\"en-GB\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\""
		"first_run_date\":\"2023-02-13+05:30\",\"windows_build_number\":19045},\"metrics\":{\"string_list\":{\"newtab.blocked_sponsors\":[]},\"string\":{\"newtab.locale\":\"en-GB\",\"newtab.newtab_category\":\"enabled\",\"newtab.homepage_category\":\"enabled\"},\"boolean\":{\"topsites.enabled\":true,\"pocket.sponsored_stories_enabled\":true,\"topsites.sponsored_enabled\":true,\"newtab.search.enabled\":true,\"pocket.enabled\":true,\"pocket.is_signed_in\":false},\"quantity\":{\"topsites.rows\":1}}}", 
		LAST);

	web_custom_request("3e4d9dff-0d29-4c59-8c46-bbe4392e1d76", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/3e4d9dff-0d29-4c59-8c46-bbe4392e1d76", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":4,\"start_time\":\"2024-02-24T05:55:23.000+05:30\",\"end_time\":\"2024-02-24T06:07:36.574+05:30\",\"reason\":\"active\",\"experiments\":{\"fox-guide-reader-mode-existing-user-part-2\":{\"branch\":\"treatment-d\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\""
		"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":"
		"{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"windows_build_number\":19045,\"app_build\":\"20240213221259\",\"os_version\":\"10.0\",\"locale\":\"en-GB\",\"app_display_version\":\"123.0\",\"architecture\":\"x86_64\",\"os\":\"Windows\",\"app_channel\":\"release\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\"},\"metrics\":{\"uuid\":{\"legacy.telemetry.client_id\":\""
		"e84f4b7b-8d91-483a-9aa4-2d9b47c1055c\"},\"counter\":{\"browser.engagement.active_ticks\":15,\"browser.engagement.uri_count\":2},\"labeled_counter\":{\"glean.validation.pings_submitted\":{\"baseline\":1,\"events\":1,\"newtab\":1,\"use-counters\":1}},\"datetime\":{\"glean.validation.first_run_hour\":\"2023-02-13T17+05:30\"}}}", 
		LAST);

	/* login */

	lr_think_time(50);
    web_reg_save_param("TokenParam", "LB=\"token\":\"","RB=\"","Search=Body", LAST);

	web_custom_request("login", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"email\":\"{username}\",\"password\":\"{password}\"}", 
		LAST);
    web_add_auto_header("Authorization","Bearer {TokenParam}");

	web_url("contactList", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);
    

	web_custom_request("contacts", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("canonical.html_2", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	/* Add a new contact */

	lr_think_time(15);

	web_url("addContact", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(39);

	web_custom_request("contacts_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"firstName\":\"Aiswarya\",\"lastName\":\"Saju\",\"birthdate\":\"1998-09-27\"}", 
		LAST);

	web_url("contactList_2", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/addContact", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("contacts_3", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
