Action()
{

	web_url("canonical.html", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_custom_request("ocsp.r2m01.amazontrust.com", 
		"URL=http://ocsp.r2m01.amazontrust.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x0B\\xC7\\xE2D\\xDFq\\xD14\\xC0\\xFD\\xCD\\xE3\\xE7\\x11\\xBA\\x8F", 
		LAST);

	web_custom_request("r3.o.lencr.org", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04ZC\\x95t\\x80\\x04+\\x1E\\x82\\xA3\\x1Co\\x86\\xD5\\xE1\\xA8\\xAA", 
		LAST);

	web_custom_request("r3.o.lencr.org_2", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x038.\\xEF\\xAAG\\x99\\xEE\\xC7\\xD7\\xE9\\xBE\\xB7o\\xBBfr\\xB6", 
		LAST);

	web_url("v1", 
		"URL=https://firefox.settings.services.mozilla.com/v1/", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("r3.o.lencr.org_3", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\x0F\\xE5\\x1A\\x0E}\\x8A\\xBD\\x03\\x1F\\x8E\\x80I\\xDE\\x03\\x90\\xEC_", 
		LAST);

	web_custom_request("r3.o.lencr.org_4", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04ZC\\x95t\\x80\\x04+\\x1E\\x82\\xA3\\x1Co\\x86\\xD5\\xE1\\xA8\\xAA", 
		LAST);

	web_custom_request("ocsp.digicert.com", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x01\\xE0c\\x8B\\x9A\\xDF\\x9CB\\x9B\\x90\\xA4n\\xB9\\x86\\x06\\x06", 
		LAST);

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("cfr-v1-en-GB", 
		"URL=https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/ms-language-packs/records/cfr-v1-en-GB", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_connect("ID=0", 
		"URI=ws://ocsp.r2m01.amazontrust.com/", 
		"Origin=wss://push.services.mozilla.com/", 
		"SecWebSocketExtensions=permessage-deflate", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1708765029945\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	web_custom_request("0350379b-268e-4fcb-bc38-96736c7dd094", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/events/1/0350379b-268e-4fcb-bc38-96736c7dd094", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":5,\"start_time\":\"2024-02-24T12:20:49.000+05:30\",\"end_time\":\"2024-02-24T14:55:04.940+05:30\",\"reason\":\"startup\",\"experiments\":{\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"fox-guide-reader-mode-existing-user-part-2\":{\"branch\":\"treatment-d\",\"extra\":{\"type\":\""
		"nimbus-nimbus\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\""
		",\"extra\":{\"type\":\"nimbus-rollout\"}},\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\""
		"extra\":{\"type\":\"nimbus-nimbus\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"first_run_date\":\"2023-02-13+05:30\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\",\"windows_build_number\":19045,\"os_version\":\"10.0\",\"architecture\":\"x86_64\",\"locale\":\"en-GB\",\"app_channel\":\"release\",\"os\":\"Windows\",\"app_build\":\"20240213221259\",\"app_display_version\":\"123.0\"},\"metrics\":{\"uuid\":{\""
		"legacy.telemetry.client_id\":\"e84f4b7b-8d91-483a-9aa4-2d9b47c1055c\"},\"boolean\":{\"urlbar.pref_suggest_nonsponsored\":false,\"urlbar.pref_suggest_sponsored\":false,\"urlbar.pref_suggest_data_collection\":false,\"urlbar.pref_suggest_topsites\":true},\"quantity\":{\"urlbar.pref_max_results\":10}},\"events\":[{\"timestamp\":0,\"category\":\"fog.validation\",\"name\":\"validate_early_event\"},{\"timestamp\":426,\"category\":\"webcompatreporting\",\"name\":\"reason_dropdown\",\"extra\":{\"setting\""
		":\"required\"}},{\"timestamp\":1014,\"category\":\"nimbus_events\",\"name\":\"validation_failed\",\"extra\":{\"experiment\":\"next-generation-accessibility-engine-powering-screen-readers\",\"feature\":\"accessibilityCache\",\"reason\":\"invalid-feature\"}},{\"timestamp\":1014,\"category\":\"nimbus_events\",\"name\":\"is_ready\"}]}", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_custom_request("ocsp.digicert.com_2", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x06'd\\xBD\\xAC\\x97O,\nP\\xA8l\\xF3\\xF9\\x00\\xA6", 
		LAST);

	web_custom_request("r3.o.lencr.org_5", 
		"URL=http://r3.o.lencr.org/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14H\\xDA\\xC9\\xA0\\xFB+\\xD3-O\\xF0\\xDEh\\xD2\\xF5g\\xB75\\xF9\\xB3\\xC4\\x04\\x14\\x14.\\xB3\\x17\\xB7XV\\xCB\\xAEP\t@\\xE6\\x1F\\xAF\\x9D\\x8B\\x14\\xC2\\xC6\\x02\\x12\\x03\\x0F\\xE5\\x1A\\x0E}\\x8A\\xBD\\x03\\x1F\\x8E\\x80I\\xDE\\x03\\x90\\xEC_", 
		LAST);

	web_url("update.xml", 
		"URL=https://aus5.mozilla.org/update/6/Firefox/123.0/20240213221259/WINNT_x86_64-msvc-x64/en-GB/release/Windows_NT%252010.0.0.0.19045.3324%2520(x64)/ISET%3ASSE4_2%2CMEM%3A12287/default/default/update.xml?force=1", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("c456dab6-a1ea-4824-bfc6-f1f52539e776", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/use-counters/1/c456dab6-a1ea-4824-bfc6-f1f52539e776", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":4,\"start_time\":\"2024-02-24T12:20:45.000+05:30\",\"end_time\":\"2024-02-24T14:54:59.377+05:30\",\"reason\":\"app_shutdown_confirmed\",\"experiments\":{\"fox-guide-reader-mode-existing-user-part-2\":{\"branch\":\"treatment-d\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a"
		"\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"device-migration-q4-spotlights-remaining-population\":{\""
		"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\",\"windows_build_number\":19045,\"app_channel\":\"release\",\"app_build\":\"20240213221259\",\"app_display_version\":\"123.0\",\"architecture\":\"x86_64\",\"locale\":\"en-GB\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\"},\"metrics\":{\"counter\":"
		"{\"use.counter.css.doc.css_text_shadow\":1,\"use.counter.css.doc.css_align_self\":1,\"use.counter.css.doc.css_border_style\":1,\"use.counter.css.doc.css_overflow_y\":1,\"use.counter.css.doc.css_left\":1,\"use.counter.css.doc.css_padding_top\":1,\"use.counter.css.doc.widows\":1,\"use.counter.css.page.css_font_family\":6,\"use.counter.css.doc.css_border_bottom_width\":1,\"use.counter.doc.window_touch\":1,\"use.counter.css.doc.css_padding_right\":1,\"use.counter.css.doc.css_white_space\":1,\""
		"use.counter.page.mixed_content_not_upgraded_image_success\":1,\"use.counter.css.page.css_border\":6,\"use.counter.css.doc.css_border_top_width\":1,\"use.counter.css.doc.css_list_style_type\":1,\"use.counter.page.mixed_content_not_upgraded_image_failure\":4,\"use.counter.css.doc.css_border_right_width\":1,\"use.counter.css.doc.css_animation\":1,\"use.counter.css.doc.css_display\":6,\"use.counter.css.doc.css_color\":6,\"use.counter.css.doc.css_max_height\":1,\"use.counter.css.doc.css_padding_bottom"
		"\":1,\"use.counter.css.page.css_color\":6,\"use.counter.css.doc.css_border_top\":6,\"use.counter.css.doc.css_border_bottom_style\":1,\"use.counter.css.doc.css_border_top_color\":1,\"use.counter.css.doc.css_border_bottom_right_radius\":1,\"use.counter.css.doc.css_border_top_style\":1,\"use.counter.css.doc.css_overflow_x\":1,\"use.counter.css.doc.css_page_break_after\":1,\"use.counter.css.doc.css_position\":6,\"use.counter.css.page.css_font_size\":6,\"use.counter.css.doc.css_touch_action\":1,\""
		"use.counter.css.doc.css_font_variant\":1,\"use.counter.css.doc.css_webkit_user_select\":1,\"use.counter.css.page.css_margin_top\":6,\"use.counter.css.doc.css_border_collapse\":6,\"use.counter.css.doc.css_padding\":6,\"use.counter.css.doc.css_border_spacing\":1,\"use.counter.css.doc.css_webkit_appearance\":1,\"use.counter.css.doc.css_align_items\":1,\"use.counter.css.doc.css_font_family\":6,\"use.counter.css.page.css_flex_direction\":6,\"use.counter.css.doc.css_opacity\":1,\""
		"use.counter.css.doc.css_webkit_animation\":1,\"use.counter.css.doc.css_color_adjust\":1,\"use.counter.css.doc.css_max_width\":6,\"use.counter.css.doc.css_word_wrap\":1,\"use.counter.css.page.css_padding\":6,\"use.counter.css.doc.css_text_align\":1,\"use.counter.css.doc.css_webkit_transition\":1,\"use.counter.css.doc.css_border\":6,\"use.counter.css.doc.css_outline_offset\":1,\"use.counter.css.doc.css_background_position\":1,\"use.counter.doc.mixed_content_not_upgraded_image_success\":1,\""
		"use.counter.css.doc.css_font_size\":6,\"use.counter.css.page.css_max_width\":6,\"use.counter.css.doc.css_transform\":1,\"use.counter.top_level_content_documents_destroyed\":6,\"use.counter.css.doc.css_min_height\":6,\"use.counter.css.page.css_display\":6,\"use.counter.css.doc.css_clip\":1,\"use.counter.css.doc.css_font_weight\":1,\"use.counter.css.doc.css_border_bottom\":1,\"use.counter.css.doc.css_border_top_right_radius\":1,\"use.counter.css.doc.css_letter_spacing\":1,\""
		"use.counter.css.doc.css_list_style\":1,\"use.counter.css.doc.css_justify_content\":1,\"use.counter.css.doc.css_list_style_position\":1,\"use.counter.css.doc.css_page_break_inside\":1,\"use.counter.css.doc.css_background_image\":1,\"use.counter.page.console_log\":1,\"use.counter.css.doc.css_margin\":6,\"use.counter.css.doc.css_user_select\":1,\"use.counter.css.doc.css_border_radius\":1,\"use.counter.css.doc.css_line_height\":1,\"use.counter.content_documents_destroyed\":6,\""
		"use.counter.css.doc.css_vertical_align\":1,\"use.counter.css.doc.css_background_size\":1,\"use.counter.css.doc.css_margin_right\":1,\"use.counter.css.doc.css_text_decoration\":1,\"use.counter.css.doc.css_text_rendering\":1,\"use.counter.css.doc.css_height\":1,\"use.counter.css.page.css_position\":6,\"use.counter.css.doc.css_visibility\":1,\"use.counter.css.page.css_min_height\":6,\"use.counter.css.doc.css_padding_left\":1,\"use.counter.css.page.css_top\":6,\"use.counter.css.doc.css_text_transform"
		"\":1,\"use.counter.css.doc.css_moz_appearance\":1,\"use.counter.css.doc.css_transition\":1,\"use.counter.css.doc.css_z_index\":1,\"use.counter.css.doc.css_border_bottom_left_radius\":1,\"use.counter.css.doc.css_moz_hyphens\":1,\"use.counter.dedicated_workers_destroyed\":5,\"use.counter.css.doc.css_font_style\":1,\"use.counter.css.doc.css_top\":6,\"use.counter.css.doc.css_moz_user_select\":1,\"use.counter.css.doc.css_hyphens\":1,\"use.counter.css.doc.css_order\":1,\"use.counter.doc.window_keyboard"
		"\":1,\"use.counter.css.doc.css_clear\":1,\"use.counter.css.doc.css_webkit_box_shadow\":1,\"use.counter.css.doc.css_border_left_width\":1,\"use.counter.css.page.css_flex_grow\":6,\"use.counter.css.doc.css_outline\":1,\"use.counter.css.doc.css_border_left_color\":1,\"use.counter.css.doc.css_border_left_style\":1,\"use.counter.css.doc.css_float\":1,\"use.counter.css.doc.css_flex_direction\":6,\"use.counter.doc.document_featurepolicy\":1,\"use.counter.css.doc.css_margin_top\":6,\""
		"use.counter.css.doc.css_text_overflow\":1,\"use.counter.css.page.css_width\":6,\"use.counter.css.doc.css_bottom\":1,\"use.counter.css.doc.css_border_color\":1,\"use.counter.css.doc.webkit_font_smoothing\":1,\"use.counter.css.doc.css_border_top_left_radius\":1,\"use.counter.css.doc.css_appearance\":1,\"use.counter.css.page.css_border_top\":6,\"use.counter.css.doc.css_transform_origin\":1,\"use.counter.css.doc.css_align_content\":1,\"use.counter.css.doc.css_background\":1,\""
		"use.counter.css.doc.css_margin_left\":1,\"use.counter.css.page.css_right\":6,\"use.counter.css.doc.css_overflow\":1,\"use.counter.doc.mixed_content_not_upgraded_image_failure\":3,\"use.counter.css.doc.css_font\":1,\"use.counter.css.page.css_border_collapse\":6,\"use.counter.css.doc.css_box_sizing\":1,\"use.counter.css.doc.css_flex_flow\":1,\"use.counter.css.doc.css_flex_grow\":6,\"use.counter.css.doc.css_background_repeat\":1,\"use.counter.css.doc.css_backface_visibility\":1,\""
		"use.counter.css.doc.css_border_left\":1,\"use.counter.css.doc.css_webkit_transform\":1,\"use.counter.css.doc.css_width\":6,\"use.counter.doc.console_log\":1,\"use.counter.css.doc.css_background_origin\":1,\"use.counter.css.doc.css_border_width\":1,\"use.counter.css.doc.css_box_shadow\":1,\"use.counter.css.doc.css_cursor\":1,\"use.counter.css.doc.css_flex_wrap\":1,\"use.counter.css.doc.css_right\":6,\"use.counter.css.doc.orphans\":1,\"use.counter.css.page.css_margin_bottom\":6,\""
		"use.counter.css.page.css_margin\":6,\"use.counter.css.doc.css_flex_basis\":1,\"use.counter.css.doc.css_border_right_style\":1,\"use.counter.css.doc.css_flex\":1,\"use.counter.css.doc.css_margin_bottom\":6,\"use.counter.css.doc.css_moz_transition\":1,\"use.counter.css.doc.css_content\":1,\"use.counter.css.doc.css_border_right\":1,\"use.counter.css.doc.css_min_width\":1,\"use.counter.css.doc.css_background_color\":1}}}", 
		LAST);

	web_custom_request("f335db19-8892-45fa-b01e-ead0be45e1fb", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/pageload/1/f335db19-8892-45fa-b01e-ead0be45e1fb", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":2,\"start_time\":\"2024-02-24T12:20:50.000+05:30\",\"end_time\":\"2024-02-24T14:55:04.961+05:30\",\"reason\":\"startup\"},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"first_run_date\":\"2023-02-13+05:30\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"windows_build_number\":19045,\"os\":\"Windows\",\"locale\":\"en-GB\",\"app_channel\":\"release\",\"app_display_version\":\"123.0\",\"app_build\":\"20240213221259\",\"architecture\":\"x86_64\",\"os_version\":\""
		"10.0\"},\"events\":[{\"timestamp\":0,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"dns_lookup_time\":\"101\",\"lcp_time\":\"2759\",\"load_type\":\"NORMAL\",\"load_time\":\"3198\",\"js_exec_time\":\"0\",\"fcp_time\":\"2802\",\"response_time\":\"2181\",\"http_ver\":\"1\"}},{\"timestamp\":51573,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"js_exec_time\":\"1\",\"load_type\":\"STOP\",\"lcp_time\":\"617\",\"load_time\":\"1346\",\"same_origin_nav\":\"true\",\"fcp_time\":\"647\","
		"\"http_ver\":\"1\",\"response_time\":\"261\"}},{\"timestamp\":67358,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"load_type\":\"STOP\",\"same_origin_nav\":\"true\",\"load_time\":\"801\",\"http_ver\":\"1\",\"response_time\":\"263\",\"fcp_time\":\"602\",\"js_exec_time\":\"0\",\"lcp_time\":\"567\"}},{\"timestamp\":82665,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"js_exec_time\":\"0\",\"http_ver\":\"1\",\"load_time\":\"781\",\"same_origin_nav\":\"true\",\"fcp_time\":\"616\","
		"\"response_time\":\"266\",\"load_type\":\"STOP\",\"lcp_time\":\"581\"}},{\"timestamp\":105536,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"load_time\":\"573\",\"response_time\":\"266\",\"http_ver\":\"1\",\"js_exec_time\":\"0\",\"same_origin_nav\":\"true\",\"load_type\":\"STOP\"}},{\"timestamp\":106607,\"category\":\"perf\",\"name\":\"page_load\",\"extra\":{\"same_origin_nav\":\"true\",\"lcp_time\":\"568\",\"load_type\":\"STOP\",\"response_time\":\"261\",\"fcp_time\":\"602\",\""
		"js_exec_time\":\"0\",\"http_ver\":\"1\",\"load_time\":\"772\"}}]}", 
		LAST);

	web_custom_request("26644644-62a4-47c3-baa7-1bdf56d64f52", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/26644644-62a4-47c3-baa7-1bdf56d64f52", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":11,\"start_time\":\"2024-02-24T12:20:50.000+05:30\",\"end_time\":\"2024-02-24T14:55:05.016+05:30\",\"reason\":\"component_init\"},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"windows_build_number\":19045,\"app_build\":\"20240213221259\",\"os\":\"Windows\",\"app_channel\":\"release\",\"os_version\":\"10.0\",\"app_display_version\":\"123.0\",\"architecture\":\"x86_64\",\"locale\":\"en-GB\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\",\"build_date\":\""
		"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\"},\"metrics\":{\"string\":{\"newtab.newtab_category\":\"enabled\",\"newtab.homepage_category\":\"enabled\",\"newtab.locale\":\"en-GB\"},\"quantity\":{\"topsites.rows\":1},\"string_list\":{\"newtab.blocked_sponsors\":[]},\"boolean\":{\"pocket.sponsored_stories_enabled\":true,\"newtab.search.enabled\":true,\"pocket.is_signed_in\":false,\"topsites.enabled\":true,\"topsites.sponsored_enabled\":true,\"pocket.enabled\":true}}}", 
		LAST);

	web_custom_request("17816e68-9e7c-42c8-92f0-3cd13f04ae55", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/17816e68-9e7c-42c8-92f0-3cd13f04ae55", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":10,\"start_time\":\"2024-02-24T13:47:51.000+05:30\",\"end_time\":\"2024-02-24T14:55:05.081+05:30\",\"reason\":\"active\",\"experiments\":{\"device-migration-q4-spotlights-remaining-population\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"mozillaaccounts-toolbar-button-default-visibility-existing-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\""
		"nimbus-rollout\"}},\"fox-guide-reader-mode-existing-user-part-2\":{\"branch\":\"treatment-d\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"spocs-endpoint-rollout-release\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"picture-in-picture-first-time-use-callout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"extensions-migration-in-import-wizard-116-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"56.1.0\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2023-02-13+05:30\",\"client_id\":\"b15c2122-a8ac-496f-a186-095bffc440f6\",\"windows_build_number\":19045,\"locale\":\"en-GB\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"app_build\":\"20240213221259\",\"app_channel\":\"release\",\"architecture\":"
		"\"x86_64\",\"app_display_version\":\"123.0\"},\"metrics\":{\"labeled_counter\":{\"glean.error.invalid_state\":{\"glean.baseline.duration\":1},\"glean.validation.pings_submitted\":{\"baseline\":1,\"events\":1,\"newtab\":1,\"pageload\":1,\"use-counters\":1}},\"uuid\":{\"legacy.telemetry.client_id\":\"e84f4b7b-8d91-483a-9aa4-2d9b47c1055c\"},\"counter\":{\"browser.engagement.active_ticks\":1},\"datetime\":{\"glean.validation.first_run_hour\":\"2023-02-13T17+05:30\"}}}", 
		LAST);

	/* signup */

	lr_think_time(16);

	web_url("addUser", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/addUser", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}